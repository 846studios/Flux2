import React, { useState } from 'react';
import { useImageContext } from '../context/ImageContext';
import OptionsPanel from './OptionsPanel';
import { Download } from 'lucide-react';

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const { generateImage, imageUrl, isLoading, error } = useImageContext();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await generateImage(prompt);
  };

  const handleDownload = () => {
    if (imageUrl) {
      const link = document.createElement('a');
      link.href = imageUrl;
      link.download = 'generated-image.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Enter your image prompt"
          className="w-full p-2 border border-gray-300 rounded"
          required
        />
        <button
          type="submit"
          className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 transition-colors disabled:bg-blue-300"
          disabled={isLoading}
        >
          {isLoading ? 'Generating...' : 'Generate Image'}
        </button>
      </form>

      <OptionsPanel />

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      {imageUrl && (
        <div className="space-y-4">
          <div className="border border-gray-300 rounded p-2">
            <img src={imageUrl} alt="Generated" className="w-full h-auto" />
          </div>
          <button
            onClick={handleDownload}
            className="flex items-center justify-center w-full bg-green-500 text-white p-2 rounded hover:bg-green-600 transition-colors"
          >
            <Download className="mr-2" size={20} />
            Download Image
          </button>
        </div>
      )}
    </div>
  );
};

export default ImageGenerator;