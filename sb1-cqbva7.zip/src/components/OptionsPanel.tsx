import React from 'react';
import { useImageContext } from '../context/ImageContext';

const OptionsPanel: React.FC = () => {
  const { options, setOptions } = useImageContext();

  const handleSeedChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setOptions({ ...options, seed: parseInt(e.target.value) });
  };

  const handleSizeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const [width, height] = e.target.value.split('x').map(Number);
    setOptions({ ...options, width, height });
  };

  return (
    <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
      <div className="flex-1">
        <label htmlFor="seed" className="block text-sm font-medium text-gray-700 mb-1">
          Seed
        </label>
        <input
          type="number"
          id="seed"
          value={options.seed}
          onChange={handleSeedChange}
          className="w-full p-2 border border-gray-300 rounded"
          min="0"
          max="1000000"
        />
      </div>
      <div className="flex-1">
        <label htmlFor="size" className="block text-sm font-medium text-gray-700 mb-1">
          Image Size
        </label>
        <select
          id="size"
          value={`${options.width}x${options.height}`}
          onChange={handleSizeChange}
          className="w-full p-2 border border-gray-300 rounded"
        >
          <option value="512x512">512x512</option>
          <option value="768x768">768x768</option>
          <option value="1024x1024">1024x1024</option>
        </select>
      </div>
    </div>
  );
};

export default OptionsPanel;