import React, { createContext, useContext, useState, ReactNode } from 'react';

interface ImageOptions {
  seed: number;
  width: number;
  height: number;
}

interface ImageContextType {
  imageUrl: string | null;
  isLoading: boolean;
  error: string | null;
  options: ImageOptions;
  generateImage: (prompt: string) => Promise<void>;
  setOptions: React.Dispatch<React.SetStateAction<ImageOptions>>;
}

const ImageContext = createContext<ImageContextType | undefined>(undefined);

export const useImageContext = () => {
  const context = useContext(ImageContext);
  if (!context) {
    throw new Error('useImageContext must be used within an ImageProvider');
  }
  return context;
};

interface ImageProviderProps {
  children: ReactNode;
}

const HUGGINGFACE_API_KEY = import.meta.env.VITE_HUGGINGFACE_API_KEY;

export const ImageProvider: React.FC<ImageProviderProps> = ({ children }) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [options, setOptions] = useState<ImageOptions>({
    seed: 123,
    width: 1024,
    height: 1024,
  });

  const generateImage = async (prompt: string) => {
    setIsLoading(true);
    setError(null);
    try {
      if (!HUGGINGFACE_API_KEY || HUGGINGFACE_API_KEY === 'your_huggingface_api_key_here') {
        throw new Error('Hugging Face API key is not provided. Please set it in the .env file.');
      }
      const response = await fetch(
        "https://api-inference.huggingface.co/models/flux-1-schnell",
        {
          headers: { Authorization: `Bearer ${HUGGINGFACE_API_KEY}` },
          method: "POST",
          body: JSON.stringify({
            inputs: prompt,
            parameters: {
              seed: options.seed,
              width: options.width,
              height: options.height,
            },
          }),
        }
      );
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate image with Flux');
      }
      const blob = await response.blob();
      const imageUrl = URL.createObjectURL(blob);
      setImageUrl(imageUrl);
    } catch (error) {
      console.error('Error generating image:', error);
      setError(error instanceof Error ? error.message : 'An unexpected error occurred');
      setImageUrl(null);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ImageContext.Provider value={{ imageUrl, isLoading, error, options, generateImage, setOptions }}>
      {children}
    </ImageContext.Provider>
  );
};